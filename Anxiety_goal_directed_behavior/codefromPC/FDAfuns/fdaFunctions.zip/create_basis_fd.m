function basisobj = create_basis_fd(type, rangeval, nbasis, params)
%  CREATE_BASIS_FD  An alternative call to BASIS.

  basisobj = basis(type, rangeval, nbasis, params);


