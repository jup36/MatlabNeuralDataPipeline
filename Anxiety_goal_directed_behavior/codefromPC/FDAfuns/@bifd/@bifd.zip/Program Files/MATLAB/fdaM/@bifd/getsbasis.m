function sbasisobj = getsbasis(bifd)
sbasisobj = bifd.sbasisobj;