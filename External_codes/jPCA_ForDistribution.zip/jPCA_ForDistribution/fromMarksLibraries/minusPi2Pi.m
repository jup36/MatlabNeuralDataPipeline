function out = minusPi2Pi(in)

out = atan2(sin(in), cos(in));

end